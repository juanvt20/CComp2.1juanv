#include <iostream>
using namespace std;

int main(){
    cout<<"  CCC   +      +\n C      +      +\nC     +++++  +++++\n C      +      +\n  CCC   +      +";
    return 0;
}