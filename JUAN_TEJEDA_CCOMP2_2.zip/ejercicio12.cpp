#include <iostream>
using namespace std;

int main(){
    int a,b,c,d,e;
    cout<<"total miles driven per day: "<<endl;
    cin>>a;
    cout<<"cost per gallon of gasoline: "<<endl;
    cin>>b;
    cout<<"average miles per gasoline: "<<endl;
    cin>>c;
    cout<<"parking fees per day: "<<endl;
    cin>>d;
    cout<<"tolls per day: "<<endl;
    cin>>e;
    cout<<"cost: "<<((a/c)*b)+d+e;
    return 0;
    }