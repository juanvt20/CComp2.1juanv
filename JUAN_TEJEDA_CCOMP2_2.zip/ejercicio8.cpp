#include <iostream>
using namespace std;

int main(){
    char a='b';
    int v=static_cast<int>(a);
    cout<<v<<endl;
    return 0;
}