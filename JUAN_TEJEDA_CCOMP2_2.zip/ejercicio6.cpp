#include <iostream>
using namespace std;
int main(){
    int a=2;
    int b=3;
    int c=12;
    if (c%a==0 && c%b==0){
        cout<<a<<" y "<<b<<" son divisores de "<<c;
    }else{
        cout<<a<<" y "<<b<<" no son divisores de "<<c;
    }
    return 0;
}