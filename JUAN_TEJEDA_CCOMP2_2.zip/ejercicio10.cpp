#include <iostream>
using namespace std;

int main(){
    int a=0;
    int b=1;
    int c=2;
    int d=3;
    int e=4;
    cout<<"Face length of cube (cm)\tSurface area of cube (cm^2)\tVolume of cube(cm^3"<<endl;
    cout<<a<<"\t"<<b<<"\t";
    return 0;
}