#include <iostream>
using namespace std;

int main(){
    int radio=5;
    float pi=3.14159;
    cout<<"diametro : "<<radio*2<<endl;
    cout<<"area : "<<pi*(radio^2);
    return 0;
}       