#include <iostream>
using namespace std;

int main(){
    int a;
    float b;
    cout<<"escribe tu peso: ";
    cin>>a;
    cout<<"escribe tu talla: ";
    cin>>b;
    float bmi=(a)/(b*b);
    cout<<"BMI VALUES\nUnderwqight:\tless than 18.5\nNormal:  \tbetwen 18.5 and 24.9\nOverweight:\tbetwen 25 and 29.9\nObese:  \t30 or greater"<<endl;
    cout<<"YOU: "<<bmi;
    return 0;
}