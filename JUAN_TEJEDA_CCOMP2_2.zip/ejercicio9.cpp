#include <iostream>
using namespace std;

int main(){
    int a=4315;
    int b=a%10;
    a=(a-b)/10;
    int c=a%10;
    a=(a-c)/10;
    int d=a%10;
    int e=(a-d)/10;
    cout<<b<<"  "<<c<<"  "<<d<<"  "<<e;
}