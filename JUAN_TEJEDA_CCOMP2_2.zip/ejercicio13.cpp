#include <iostream>
using namespace std;
int main(){
    float a;
    cout<<"edad: "<<endl;
    cin>>a;
    float b=220-a;
    float c=208-(0.7*a);
    float d=207-(0.7*a);
    float e=208-(0.64*a);

    if (b<c){
        if(b<d){
            if(b<e){
                cout<<"minimo MHR: "<<b;
            }else{
                cout<<"minimo MHR: "<<e;
            }
        }else if (d<e){
            cout<<"minimo MHR: "<<d;
        }else{
            cout<<"minimo MHR: "<<e;
        }
    }else if(c<d){
        if(c<e){
            cout<<"minimo MHR: "<<c;
        }else{
            cout<<"minimo MHR: "<<e;
        }
    }else if (d<e){
        cout<<"minimo MHR: "<<d;
    }else{
        cout<<"minimo MHR: "<<e;
    }


    if (b>c){
        if(b>d){
            if(b>e){
                cout<<"maximo MHR: "<<b;
            }else{
                cout<<"maximo MHR: "<<e;
            }
        }else if (d>e){
            cout<<"maximo MHR: "<<d;
        }else{
            cout<<"maximo MHR: "<<e;
        }
    }else if(c>d){
        if(c>e){
            cout<<"maximo MHR: "<<c;
        }else{
            cout<<"maximo MHR: "<<e;
        }
    }else if (d>e){
        cout<<"maximo MHR: "<<d;
    }else{
        cout<<"maximo MHR: "<<e;
    }
}