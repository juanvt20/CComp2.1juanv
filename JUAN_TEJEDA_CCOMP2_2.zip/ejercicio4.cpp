#include <iostream>
using namespace std;

int main(){
    int a=20;
    int b=15;
    int c=8;
    int d=0;
    int e=2;
    if (a<b){
        if (a<c){
            if (a<d){
                if (a<e){
                    cout<<"el numero mas pequeño es "<<a<<endl;
                }else{
                    cout<<"el numero mas pequeño es "<<e<<endl;
                }
            }else if(d<e){
                cout<<"el numero mas pequeño es "<<d<<endl;
            }else{
                cout<<"el numero mas pequeño es "<<e<<endl;
            }
        }else if(c<d){
            if(c<e){
                cout<<"el numero mas pequeño es "<<c<<endl;
            }
        }else{
            cout<<"el numero mas pequeño es "<<e<<endl;
        }
        
    }else if(b<c){
        if(b<d){
            if (b<e){
                cout<<"el numero mas pequeño es "<<b<<endl;
            }else{
                cout<<"el numero mas pequeño es "<<e<<endl;
            }
        }
    }else if(c<d){
        if(c<d){
            if(c<e){
                cout<<"el numero mas pequeño es "<<c<<endl;
            }
        }else{
            cout<<"el numero mas pequeño es "<<e<<endl;
        }
    }else if(d<e){
        cout<<"el numero mas pequeño es "<<d<<endl;
    }else{
        cout<<"el numero mas pequeño es "<<e<<endl;
    }


    if (a>b){
        if (a>c){
            if (a>d){
                if (a>e){
                    cout<<"el numero mas grande es "<<a<<endl;
                }else{
                    cout<<"el numero mas grande es "<<e<<endl;
                }
            }else if(d>e){
                cout<<"el numero mas grande es "<<d<<endl;
            }else{
                cout<<"el numero mas grande es "<<e<<endl;
            }
        }else if(c>d){
            if(c>e){
                cout<<"el numero mas grande es "<<c<<endl;
            }
        }else{
            cout<<"el numero mas grande es "<<e<<endl;
        }
        
    }else if(b>c){
        if(b>d){
            if (b>e){
                cout<<"el numero mas grande es "<<b<<endl;
            }else{
                cout<<"el numero mas grande es "<<e<<endl;
            }
        }
    }else if(c>d){
        if(c>d){
            if(c>e){
                cout<<"el numero mas grande es "<<c<<endl;
            }
        }else{
            cout<<"el numero mas grande es "<<e<<endl;
        }
    }else if(d>e){
        cout<<"el numero mas grande es "<<d<<endl;
    }else{
        cout<<"el numero mas grande es "<<e<<endl;
    }
    return 0;
}